# inTime
 A very small Arduino library for working with time intervals.
